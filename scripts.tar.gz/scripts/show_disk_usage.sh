#!/bin/bash
# Script pour afficher l'utilisation du disque de manière lisible

# Affiche l'utilisation du disque
echo "Utilisation du disque :"
df -h

